import React from 'react'

const Attendee = () => {
  return (
    <div>
        <p>Attendee</p>
    </div>
  )
}

export default Attendee
    