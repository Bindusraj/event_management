import React from 'react'

const Events = () => {
  return (
    <div>
        <table>
          
        </table>
    </div>
  )
}

export default Events
    