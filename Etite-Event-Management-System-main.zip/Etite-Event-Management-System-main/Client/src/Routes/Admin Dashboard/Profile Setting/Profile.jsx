import React from 'react'

const Profile = () => {
  return (
    <div>
        <p>Profile</p>
    </div>
  )
}

export default Profile
