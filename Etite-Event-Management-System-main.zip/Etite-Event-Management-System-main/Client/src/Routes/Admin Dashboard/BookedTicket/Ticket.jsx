import React from 'react'

const Ticket = () => {
  return (
    <div>
        <p>Booking Ticket</p>
    </div>
  )
}

export default Ticket;
