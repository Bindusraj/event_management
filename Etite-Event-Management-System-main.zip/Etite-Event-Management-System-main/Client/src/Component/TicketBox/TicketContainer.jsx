import React from 'react'

const TicketContainer = () => {
  return (
    <div>
      
    </div>
  )
}

export default TicketContainer
